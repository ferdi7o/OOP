from project.motorcycle import Motorcycle
class RaseMotorcycle(Motorcycle):
    DEFAULT_FUEL_CONSUMPTION: float = 8