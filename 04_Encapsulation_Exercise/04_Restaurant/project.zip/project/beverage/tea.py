from project.beverage.hot_beverag import HotBeverage


class Tea(HotBeverage):
    pass